export const produtos = [
    {
        id:0,
        img:"img/product-2.png", 
        nome:"Ração para Gatos",
        preco:147.99
    },
    {
        id:1,
        img:"img/racao_dog.png", 
        nome:"Ração para Cães",
        preco:154.99
    },
    {
        id:2,
        img:"img/product-1.png", 
        nome:"Ração para Pistacídeos",
        preco:49.99
    },
    {
        id:3,
        img:"img/repteis.png", 
        nome:"Ração para répteis",
        preco:32.99
    },
    {
        id:4,
        img:"img/medicamento.png", 
        nome:"Medicamentos",
        preco:134.99
    },   
    {
        id:5,
        img:"img/higiene.png", 
        nome:"Higiene",
        preco:42.99
    },
    {
        id:6,
        img:"img/acessorio.png", 
        nome:"Acessórios",
        preco:219.99
    },
    {
        id:7,
        img:"img/briquedo.png", 
        nome:"Brinquedos",
        preco:29.99
    },
 
]