$("#whatsapp_button").floatingWhatsApp({
  
    //your whatsapp number
   

    //popup message
    popupMessage: "Hello, how can we help you?",
    showPopup: true,

    //this is other parameter, you can use it
    //remove // below to use other parameter

    // message: "I want ask something about your product",
    // showOnIE: false,
    // headerTitle: 'Welcome!',
    // headerColor: 'crimson',
    // backgroundColor: 'crimson',

  });