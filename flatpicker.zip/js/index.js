/*Initialize the calender component*/
var calendar = new ej.calendars.Calendar();





console.log(calendar);


console.log("teste");
calendar.appendTo('#element');